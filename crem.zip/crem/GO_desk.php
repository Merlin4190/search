<?php
 $pageTitle = "G.O's Desk | Christ Redemption International";

 require('includes/config.php');

 include("includes/header.php");


?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br>G.O's Desk</h1><br>
                            <?php
            try {

                $stmt = $db->query('SELECT postID2, postTitle2, postSlug2, postDesc2, postDate2 FROM blog_posts2 ORDER BY postID2 DESC');
                while($row = $stmt->fetch()){
                    
                    echo '<div>';
                        echo '<h1 style="text-align: left;"><a href="post.php?id='.$row['postSlug2'].'">'.$row['postTitle2'].'</a></h1>';
                        echo '<p>Posted on '.date('jS M Y H:i:s', strtotime($row['postDate2'])).'</p>';
                        echo '<p>'.$row['postDesc2'].'</p>';             
                        echo '<p><a href="post.php?id='.$row['postSlug2'].'">Read More</a></p>';               
                    echo '</div>';

                }

            } catch(PDOException $e) {
                echo $e->getMessage();
            }
        ?>
                            
                              


       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>