<?php
 $pageTitle = "Prayer Request | Christ Redemption International";

include("includes/header.php");

?>

<div class="content-section">
        <div class="container">
            <div class="row">
            <p>OR SEND YOUR REQUEST TO THIS E-MAIL:<i class="fa fa-envelope"></i> <a href="mailto:info@christredemptioninternational.org">info@christredemptioninternational.org</a></p>
                <div class="col-md-9">                    
    <div class="contact">
		<div class="newslettercontent">
			<div class="leftside2">
				<img id="image_border" src="images/border.png" alt="border">
					<div class="contact-form">
						<h1>Prayer Request</h1>
							<div class="form-group group-coustume">
                            <form action="" method="post">
								<input type="text" class="form-control name-form" placeholder="Name" name="name">
								<input type="text" class="form-control email-form2" placeholder="E-mail" name="email2">
								<input type="text" class="form-control subject-form" placeholder="Subject" name="subject">
								<textarea rows="3" cols="50" class="message-form2" name="message"></textarea>
								<button type="submit" class="btn btn-default btn-submit" name="Submit">Submit</button>

                                <?php
                                $user="root";
                                $password="";
                                $database="localhost";
                                
                                mysql_connect("localhost","root","") or die("cannot connect to server");
                                mysql_select_db("christr4_crem") or die("cannot connect to database");

                                if(isset($_POST['Submit'])){$name=$_POST['name'];$email2=$_POST['email2'];$subject=$_POST['subject'];$message=$_POST['message'];

                                mysql_query("INSERT INTO request VALUES ('$name','$email2','$subject','$message')");

                                mysql_close();}

                                ?>
                            </form>                              
							</div>                                                      
					</div>                    
			</div>
			<div class="google-maps">
			 <div id="googleMap"></div>

			</div>
		</div>

	</div>



                        
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>