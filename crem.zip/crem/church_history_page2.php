<?php
 $pageTitle = "Church History | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">
                        	<p align="justify">With an unusual bravery and great faith, a piece on which the Headquarters of the church stand today was acquired. This was not with its own threats from neighbours who would rather wished that the church relocates somewhere else. Church services and revival started under cocoa trees. Gradually a small tent with thatches roof was erected. By <font color="blue">1993,</font> the first auditorium was built. At that time, Ile-Idande as is widely known today was right in the forest and cocoa farms. From the area around the railway crossing at Oke Onitea, there was hardly any notable building except the <b>Grace Baptist Church and WOSEM camp.</b> Everywhere else was forest. Then, it required determination and commitment to serving God for anyone to attend church services. There were <u>three cars</u> that belonged to church members- <u>two Volkswagen beetle cars and a regular car</u>. Most people trekked to the church with joy and satisfaction. Despite the meagre resources available to the Ministry at that time, the church was always full and programmes well attended. Every meeting came with signs and wonders and these strenghtened and encouraged the church. The Ori-Oke Prayer time had started and attendances were co0nsiderable at every meeting with many great testimonies. For many members, the memories of early days are usually nostlagic, with a yearning for revivals like the days of old.<br><br><b>Prophet T.O. Obabare</b> ministering in one of the annual Conventions of the Church in <font color="blue">1994,</font> remarked the audacity of the set man and the church in setting for a location that was so remote from the core of the city. This renowned man of God was visiting the church for the first time and would have turned back because the closer he was getting to the church with his team, the more isolated the location was becoming. It was the assurance of one of his aides that eventually brought him to the venue that afternoon. Prophet Obadare observed that new ministries at the time were all meeting in shops and free spaces such as school halls in the town, and commented that the location of the church in Ile-Idande was a confirmation that the man of God was anointed forthe service. The years that followed eloquently bore testimonies to Prophet Obadare's prophetic observations.</p><br><br><p><font size="5" color="brown"><b>The Expansion Period</b></font></p><br>The LORD continued to use His servant for great signs and wonders and these brought more and more people into the Ministry. Many of these contributed in no small measure to the development of the Ministry as earlier indicated. A major feature of the consolidation period between <font color="blue">1993 and 1995</font> was the expansion of the Ministry first to Ile-Ife. The growth was like a wild fire with attendances at the programmes growing by the day. Attendances were not only high at Ile-Ife, larger number of people turned up for the church's national programmes monthly and during Olorun Olundade prayer congresses.<br><br>The boost to the presence of the church in Ile-Ife came with the memorable Ile-Ife Wide Crusade of <font color="blue">1992.</font> The crusade had to the glory of the LORD, physical presence of the Holy Spirit with many people receiving healings and becoming Christians. It drew several men and women of God together in a magnitude that is difficult to compare with any other at that time. The ebullient and vivacious <font color="blue">Niyi Adedokun</font> opened the crusade with song ministration before the Man of God took the stage with mighty power of anointing. Niyi Adedokun had just released one of his best-selling albums- 'Awaye ma lo' around the time of the crusade and had a crowded schedule responding to several invitations for ministration all over the country then. It was only the Power of God that could have attracted him to that crusade. In the days that followed the opening, the doyen of Nigerian Gospel Music, <font color="blue">Sister Bola Are</font> joined the trail with her sonorous gospel voice, adorning her powerful singspiration with rich testimonies many of which are difficult to forget. The impact of that open air crusade is still with us and the Ministry can only say Thank You to the Caller who made everything possible.</p>
                            <ul class="pagination pagination-lg">
                            <li><a href="church_history.php">1</a></li>
                            <li class="disabled"><a href="#">2</a></li>
                            <li><a href="church_history_page3.php">3</a></li>  
                            </ul>

                        
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>