<?php
 $pageTitle = "Mount Zion International School | Christ Redemption International";

include("includes/header.php");

?>
<div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/zionlogo.png"><br></h1>
                        <h3 align="center"><font color="brown" >MOUNT ZION INTERNATIONAL SCHOOL</font><br><font size="2">(Nursery, KG, Primary)</font><br></h3>
                        <p align="center"><font  color="amber" size="2"><b>ADMISSION!ADMISSION!!ADMISSION!!!</b></font></p>
                        <p><font color="#000"><b>Address1: New Oba Road, Opposite Federal Housing Estate Ile-Idande, Osogbo.<br>Address2: Olohunlomerue Timi Agbale Road, Azeez Avenue, Ede, Osun State.</b></font></p>
						<p align="center">Offers Admission into<br><br>Nursery, KG, Primary and Secondary.</p>
						<p align="center"><img src="images/ch55.png"></p>
						<h3 align="left"><font  color="purple">Application forms are available in the school office at Ile-Idande, Osogbo, Osun State.</b></font></h3>
						<p><font color="#000"><b>Contact Address: 08033574655, 07066746001.<br>Email Address: mountzioncity@yahoo.com or zioneducation@yahoo.com</font></b></p>


                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>        
        
<?php include './includes/footer.php';?>