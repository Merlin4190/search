<?php
 $pageTitle = "Men's Conference | Christ Redemption International";

include("includes/header.php");

?>

<div class="content-section">
        <div class="container">
        <ol class="breadcrumb">
            <li><a href="photos.php">Home</a></li>
            <li class="active">photos_Men's Conference</li>
        </ol>
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">


                            <h1 align="center"><img src="images/logo1.png"><br>"MEN"S CONFERENCE 2016"</h1>
        <div class="our-partner" style="background-color: transparent;">
            <div class="row">
                <div class="col-md-12">
                    <div class="customNavigation">
                            <a class="btn prev"><i class="fa fa-angle-left"></i></a>
                            <a class="btn next"><i class="fa fa-angle-right"></i></a>
                    </div>

                    <div id="owl-demo" class="owl-carousel">
                            <div class="item"> 
                                <a href="#"><img src="images/tm-170x80-1.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-2.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-1.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-2.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-1.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-2.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-1.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-2.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-1.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/tm-170x80-2.jpg" alt=""></a>
                            </div>
                    </div> <!-- /#owl-demo -->
                </div> <!-- /.col-md-12 -->
            </div> <!-- /.row -->            
        </div> <!-- /.our-partner -->

                        



                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
               <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>