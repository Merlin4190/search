<?php
 $pageTitle = "Forgot Password | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-item-1">
                        <div class="product-content overlay" style="background-color: #2d3e50;">

                        <h1 align="center"><img src="images/logo1.png"><br><font color="#fff">Password Reset</font></h1>

                        
                        
			<form class="form-horizontal templatemo-forgot-password-form templatemo-container" role="form" action="#" method="post">	
				<div class="form-group">
		          <div class="col-md-12">
		          	Please enter your email address that you registered in our website.
		          </div>
		        </div>		
		        <div class="form-group">
		          <div class="col-md-12">
		            <input type="text" class="form-control" id="email" placeholder="Your email">	            
		          </div>              
		        </div>
		        <div class="form-group">
		          <div class="col-md-12">
		            <input type="submit" value="Submit" class="btn btn-danger">
                    <br><br>
                    <a href="login.php">Login</a>
		          </div>
		        </div>
		      </form>



       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>                
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>
	