<?php
 $pageTitle = "Events and Calendar | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br>EVENTS AND CALENDAR</h1><BR/>
                        	<h2>Weekly Programmes</h2>
							<div class="table-responsive">
								<table class="table">
									<thead>
										<tr>
											<th>DAYS OF THE WEEK</th>
											<th>PROGRAMMES</th>
											<th>TIME</th>
											<th>VENUE</th>											
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Mondays</td>
											<td>Breakthrough Prayer</td>
											<td>6am-7am</td>
											<td></td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Tuesdays</td>
											<td>1. Revelation Hours<br>2. Prayer Mountain</td>
											<td>5pm-7pm<br>9am-12pm</td>
											<td>CREM Cathedral<br>Erekusu Idande Prayer Mountain</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Wednesdays</td>
											<td>Special Night Vigil</td>
											<td>12am-5am</td>
											<td>Erekusu Idande Prayer Mountain</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Thursdays</td>
											<td>Miracle Hour</td>
											<td>5pm-7pm</td>
											<td></td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Fridays</td>
											<td>Night Vigil</td>
											<td>10pm-5am</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
								</table><BR/>
							<h2 align="center">Sunday Services</h2>
								<table class="table">
									<thead>
										<tr>
											<th>SUNDAYS</th>											
											<th>TIME</th>
											<th>VENUE</th>											
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>ENGLISH SERVICE</td>											
											<td>7am-9am</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>SUNDAY SCHOOL</td>											
											<td>9am-10am</td>
											<td>CREM Cathedral and other Branches</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>YORUBA SERVICE</td>											
											<td>10am-12am</td>
											<td>CREM Cathedral and other Branches</td>
										</tr>
									</tbody>
								</table><BR/>
							<h2 align="center">YEAR 2016 ITINERARY</h2>
								<table class="table">
									<thead>
										<tr>
											<th>EVENTS</th>											
											<th>DATE</th>
											<th>VENUE</th>											
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>SIGNS AND WONDER NIGHT</td>											
											<td>1st day of the month</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>BREAKTHROUGH AND DELIVERANCE NIGHT</td>											
											<td>1st friday of the month</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>QUARTERLY OLORUN OLUNDADE<br>PRAYER CONGRESS</td>										
											<td>MAR 25TH-27TH &<br>JUN 24TH-26TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>A DAY WITH THE LORD<br>OJO KAN PELU OLUWA</td>											
											<td>JUN 18TH-19TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>CHILDREN'S ANNUAL CONFERENCE</td>											
											<td>AUG 12TH-14TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>YOUTH ANNUAL CONFERENCE</td>											
											<td>AUG 19TH-21ST</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>EXCELLENT WOMEN'S CONFERENCE</td>											
											<td>SEPT 9TH-10TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>MEN'S ANNUAL CONFERENCE</td>											
											<td>SEPT 23RD-25TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>QUARTERLY OLORUN OLUNDADE<br>PRAYER CONGRESS</td>										
											<td> SEPT 23RD-25TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>JESUS POWER CONVENTION</td>											
											<td>OCT 3RD-9TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>QUARTERLY OLORUN OLUNDADE<br>PRAYER CONGRESS</td>										
											<td>DEC 23RD-25TH</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>END OF THE YEAR SPECIAL PRAYER CONGRESS</td>											
											<td>DEC 30TH-1ST JAN 2017</td>
											<td>CREM Cathedral</td>
										</tr>
									</tbody>
								</table>
							</div>
						


       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>