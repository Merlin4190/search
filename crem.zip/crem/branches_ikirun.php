<?php
 $pageTitle = "BRANCHES | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-thumb">                        
                        	<div class="product-content overlay">
                            <img src="images/imagess.jpeg" alt="CREM CATHEDRAL" class="cathedral">                            
                                <h2 align="center"><img src="images/logo1.png" class="logo1"><br>LIVING POWER CHURCH (CREM)<BR/>IKIRUN</h2>
                                <p><font color="#000"> If you are in IKIRUN, worship with us @CREMcathedral situated at:</font></p>
								<p><span class="fa fa-map-marker"><b> Along Ire Road, Ikirun, Osun State, Nigeria.</b></span><BR/>								
								<font color="black"> Pastor-In-Charge:</font> PASTOR RUFUS ADEEYO  <br><i class="fa fa-envelope">  <a href="mailto:cremikirun@yahoo.com">cremikirun@yahoo.com</a></i> | 
								<i class="fa fa-phone"> 08033913349</i></p>
								<img src="images/line.png" alt="line">
                                    </div>
                                    <div class="col-md-12">
                    <p style="background-color:#000; position: relative; top: 33px; width:80px;"><font color="#fff"><b>News Flash:</b></font></p><marquee behavior="scrol">A Day with the Lord annual programme will be coming up on June 18th-19th at CREM CATHEDRAL<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>
                    Also, OLORUN OLUNDADE PRAYER CONGRESS (quarterly prayer) will come up in this coming month of June 24th-26th at Erekusu Idande Prayer Mountain. Please let's endeavour to be there.<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>You can now send your Prayer request to this email:&nbsp;<i class="fa fa-envelope">&nbsp;creminternational@yahoo.com or contact our prayer line:</i> <i class="fa fa-phone">08033574655 OR 08076474324</i<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>Join hands in building a new auditorium to glorify God by donating into the church projects account.<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>You can also follow Daddy G.O on our Radio Special Programme both on Unique f.m and Ray f.m at 1:00pm - 1:15pm every Wednesday.<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>Follow us on <i class="fa fa-twitter-square">&nbsp;Twitter(@CREMworlwide)</i> & <i class="fa fa-facebook-square">&nbsp;Facebook(cremworldwide)</i></marquee></b>
                    				
           
					
					</div>


                   


                                    </div> <!-- /.product-thumb -->
                            </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                <?php include './includes/side.php';?>
                    
                </div>
            </div>
        </div>
    </div> 
     <div class="content-section" style="background-color: #2d3e50;">
       			<div class="container">                    
            		<div class="row">
                    	<div class="col-md-12 col-sm-6">
                    		<div class="product-holder">
                    <font color="#fff"><marquee direction="right" behavior="slide"><h4"> NOW AVAILABLE IN OUR STORE... </h4></marquee>
                    <div class="col-md-2 col-sm-2"><a href="payment.php"><img src="images/book.png"></a><p>Christian Books</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/steaker.jpg"></a><p>Stickers</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/calendar.jpg"></a><p>Calendars</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/disck.jpg"></a><p>Audio and Video Messages</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/bkk.jpg"></a><p>Motivational Books</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/sundaysch.jpg"></a><p>Sunday School Manual</p></div></font>
							</div>
						</div>
					</div>
				</div>
			</div>               
         
        
<?php include './includes/footer.php';?>