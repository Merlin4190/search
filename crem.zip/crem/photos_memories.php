<?php
 $pageTitle = "Memories | Christ Redemption International";

include("includes/header.php");

?>

<div class="content-section">
        <div class="container">
        <ol class="breadcrumb">
            <li><a href="photos.php">Home</a></li>
            <li class="active">photos_Memories</li>
        </ol>
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                            <h1 align="center"><img src="images/logo1.png"><br>"MEMORIES"</h1>
                        <div id="carousel-up" class="carousel slide" data-ride="carousel">                            
                            <div class="carousel-inner " role="listbox">
                                <div class="item active">
                                        <img src="images/crem/8.jpg" alt="itenary">
                                    <div class="carousel-caption">
                                    <p>Late Mother of the General Overseer (Princess Ajibola Ajike)</p>
                                    </div>
                                </div>
                                <div class="item">
                                        <img src="images/crem/3.jpg" alt="A day with the Lord">
                                    <div class="carousel-caption">
                                    <p>Congregation at Sokoto Crusade in 1989, one of the landmark of the ministry for centuries to come</p>
                                    </div>
                                </div>
                                <div class="item">
                                        <img src="images/crem/1.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>G.O's Graduation pic from CAC Theological Seminary in 1991</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/4.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Ordination day of the Man of God at CAC secretariat Ibadan in 1992</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/5.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>G.O's Graduation day at Ibadan after successfully completing his B.Th</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/44.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>1st set of Foundation members of the church in 1992</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/17.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>First Mass transit acquired by the Church</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/31.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>A view of the old church building(Ile-Idande)</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/33.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>An image of Church Headquarters with her Congregations</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/27.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Well digging at Ile-Idande, one of the development plans undertaken by the church as at then</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/42.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Headquarter's secretariat at the inception</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/37.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Erekusu-Idande Preayer Mountain at her inception</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/2.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Erekusu-Idande Prayer Mountain when started</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/6.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Erekusu-Idande Prayer Mountain when the construction of the Alter was completed</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/9.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>An on-going Prayer revival at the Prayer Mountain, Erekusu-Idande, Iganrin-Ede</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/38.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>From left to right: Deputy G.O- Prof. Adesina, his wife; The G.O, and also his wife</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/10.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>One of the Memorable Events of Jesus Power Festival</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/14.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Congregations of CREM ADA BRANCH</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/16.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Some of the congregations of CREM IBADAN ASSEMBLY</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/20.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Congregations of CREM IKIRUN BRANCH with Pastor Adeeyo as Pastior-in-charge</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/41.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Foundation laying of CREM Fellowship at Iree</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/43.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Iree Fellowship during laying of Church Foundation</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/11.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>CREM PORTHARCOURT SOUTH-SOUTH REGIONAL BRANCH(MOUNTAIN OF SOLUTION)</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/34.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>An inside view of CREM PORTHARCOURT SOUTH-SOUTH REGIONAL BRANCH(MOUNTAIN OF SOLUTION)"</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/12.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>CREM CAROL AND FATHER CHRISTMAS SHOW 2015</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/15.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>1st set of LPC Bible School Graduates</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/28.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>2nd Graduation students at LPC Bible College</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/22.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Men of Faith CREM choir during one of their conventions</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/18.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>CREM Ever gorgeous Excellent Women after one of their conventions</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/54.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Excellent Women during 2015 Jesus Power Convention</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/36.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Women of the Ministry showcasing their prowess in Drama acting during their Women's convention</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/39.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Childrens Covention- David's Generation showcasingtheir God's given talents</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/23.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Drama Group during one of the church programmes</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/19.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>A group photograph at Aafin(Palace) Oloko of Oko after a ground breaking crusade that shook the whole town"</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/21.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>A group photograph with the G.O inside the cathedral after the completion of the lintel part of the bulding</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/24.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Deputy General Overseer(Prof. Adesina) during one of his ministrations</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/25.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>G.O and his wife during a thanksgiving ceremony</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/26.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>10th Anniversary Celebration of the Church with the cutting of the cake as a mark of celebration</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/29.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>A group photograph of the church evergreen CREM VOICES</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/30.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Children, Santa Claus alongside the General Overseer of the ministry during one of the christmas celebration</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/32.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Prophet T.O Gabriel in Graduation Gown after his successful completion of his B.Th at Ibadan</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/35.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Prophet T.O Gabriel with his wife(Lady Evang. Oluwabukola Comfort Gabriel) during his graduation at ibadan</p>
                                    </div>
                            </div>
                            <div class="item">
                                        <img src="images/crem/40.jpg" alt="Oludande Prayer Congress">
                                    <div class="carousel-caption">
                                    <p>Wife of the G.O, President CREM Excellent Women- Lady Evang. Oluwabukola Comfort Gabriel ministring</p>
                                    </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-up" role="button" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span></a>

                            <a class="right carousel-control" href="#carousel-up" role="button" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span></a>

                        </div>
                        </div>
                        



                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>