<?php
 $pageTitle = "Testimony | Christ Redemption International";

include("includes/header.php");

?>

<div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">

<div class="allcontain">                
    <div class="contact">
		<div class="newslettercontent">
			<div class="leftside">
				<img id="image_border" src="images/border.png" alt="border">
					<div class="contact-form">
						<h1>Testimony</h1>
							<div class="form-group group-coustume">
                            <form action="" method="post">
                                <input type="text" class="form-control name-form" placeholder="Name" name="name1">
                                <input type="text" class="form-control email-form2" placeholder="E-mail" name="email3">
                                <input type="text" class="form-control subject-form" placeholder="Subject" name="subject1">
                                <textarea rows="3" cols="50" class="message-form2" name="message1"></textarea>
                                <button type="submit" class="btn btn-default btn-submit" name="Submit">Submit</button>

                                <?php
                                $user="root";
                                $password="";
                                $database="localhost";
                                
                                mysql_connect("localhost","root","") or die("cannot connect to server");
                                mysql_select_db("christr4_crem") or die("cannot connect to database");

                                if(isset($_POST['Submit'])){$name1=$_POST['name1'];$email3=$_POST['email3'];$subject1=$_POST['subject1'];$message1=$_POST['message1'];

                                mysql_query("INSERT INTO testimony VALUES ('$name1','$email3','$subject1','$message1')");

                                mysql_close();}

                                ?>
                            </form>
							</div>
					</div>
			</div>
			<div class="google-maps">
			 <div id="googleMap"></div>

			</div>
		</div>

	</div>
</div>



                        
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>