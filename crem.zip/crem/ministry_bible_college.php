<?php
 $pageTitle = "International Theological Seminary | Christ Redemption International";

include("includes/header.php");

?>
<div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br></h1>
                        <h3 align="center"><font color="brown" >INTERNATIONAL THEOLOGICAL SEMINARY</font><br><font size="2">New Oba Road, Opposite Federal Housing Estate Ile-Idande.</font><br></h3>
                        <p align="center"><font  color="amber" size="2"><b>ADMISSION!ADMISSION!!ADMISSION!!!</b></font></p>
                        <p align="center">Offers Admission into<br><br>Certificate and Diploma courses in <b>THEOLOGY, EVANGELISM, PROPHETIC, PASTORAL, MISSION AND CHILDREN EDUCATION.</b></p>
                        <p><font color="#000"><b>Admission Requirements:</b></font><br>1. Primary School Leaving Certificate<br>2. Modern School Leaving Certificate<br>3. Junior Secondary School Leaving Certificate<br>4. Ordinary Level, HND and Degree.<br><p><font color="#000"><b>Spiritual Requirements:</b></font><br>1. Born Again<br>2. Holy Spirit of filled called by God into Ministry.</font></p>						
						<h3 align="left"><font  color="purple">Application forms is obtained at the college office at the above address and all LPC World-Wide.</font></h3>
						<p><font color="#000"><b>Contacting Acting Pastor- 08033574655, 08053851855, 07066746001.</b></font></p>


                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>        
        
<?php include './includes/footer.php';?>