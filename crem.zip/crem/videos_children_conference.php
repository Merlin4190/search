<?php
 $pageTitle = "Videos & Audios | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
        <ol class="breadcrumb">
            <li><a href="videos_audios.php">Home</a></li>
            <li class="active">videos_children's conference</li>
        </ol>
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br>VIDEOS AND AUDIOS<br>
                        <div class="embed-responsive embed-responsive-16by9">
                        	<video  autoplay loop class="embed-responsive-item" controls>
                                <source src="videos/children.mp4" type="video/mp4" />
                                
                                Your browser does not support the video tag.
                            </video>
                            

                        </div>
                        <BR/>
                        <div class="embed-responsive embed-responsive-16by9">
                            <video   loop class="embed-responsive-item" controls>
                                <source src="videos/children2.mp4" type="video/mp4" />
                                
                                Your browser does not support the video tag.
                            </video>
                            

                        </div>
                        </h1>
       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
                            <BR/>
                            <BR/>
                            <ul>
                            <font color="#2a6496" size="3px"><b>Playlists</b></font>
                                <li><a href="#"> PROPHETIC MESSAGES</a></li>
                                <li><a href="#"> Clips from CHILDREN ANNUAL CONVENTION</a></li>
                                <li><a href=""> Clips from CREM YOUTH CONFERENCE</a></li>
                                <li><a href=""> Clips from EXCELLENT WOMEN CONVENTION</a></li>
                            </ul>
                        
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>