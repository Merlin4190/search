<?php
 $pageTitle = "Christ Redemption International";

include("includes/header.php");

?>

    <!--_______________________________________ Carousel__________________________________ -->
<div class="allcontain">
    <div id="carousel-up" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner " role="listbox">
            <div class="item active">
                <img src="images/jpf.jpg" alt="Jesus Power Festival">
                
            </div>
            <div class="item">
                <a href="live_blog_day1.php"><img src="images/live.jpg" alt="Live Blog"></a>
                
            </div>
            <div class="item">
                <img src="images/itenary.png" alt="itenary">
                
            </div>
            <div class="item">
                <img src="images/oludande2.png" alt="Oludande Prayer Congress">
                
            </div>
            <div class="item">
                <img src="images/cyc.png" alt="Crem Youth Conference">
                
            </div>
            <div class="item">
                <img src="images/camp.png" alt="Oludande Prayer Camp">
                
            </div>
        </div>

    <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-thumb">
                            <img src="images/g.omum.jpg" alt="General Overseer and Wife" class="GO">
                            <div class="product-content overlay">
                                <b><font color="brown" face="Verdana, Tahoma, Helvetica" size="5">YOU ARE WELCOME!</font></b> 
                                    <p align="justify">In the name of Jesus Christ our Lord, we welcome you to this e-site. It is a great delight that you have created time to surf this site. It is my earnest prayer 
                                    that the Lord will meet you all in a way you will never forget as He met Hannah in <strong>Shiloh(1 Samuel 1:9-17)</strong> in Jesus name. Amen.<br>
                                    You can find out information,latest posts and news on the happenings around Christ Redemption International and how you can be part of the progress and project ongoing.<br>
                                    The founding pastor and the General Overseer of the Church and Ministry is <b>Pastor/Prophet Tilufoye Olaitan Ojediran Gabriel,</b> who was ordained a minister of God in 1989. Born in the traditional town of Ede in Osun State into a Muslim 
                                    family, Pastor Gabriel had a broad based training in core theology and various aspects of evangelism and church planting all of which God has used to prepare him for the task of presiding over a church. 
                                    A dogged, fearless and consummate minister of the Gospel with penchant for hard work even when conditions are hostile; and a deep lover of people, Pastor Gabriel had in the early stages of his calling, 
                                    ministered to and touched several souls as a Prophet and an Evangelist in many churches across the country, reaching as far as Sokoto in Sokoto State in the early 80s. 
                                    <a href="church_history.php" class="footer"><font color="brown"><b>Continue Reading</b></font></a><br><br>To worship with us at any of our various branches, kindly click on 
                                    <a href="branches.php" class="footer"><font color="brown"><b>Branches</b></font></a><br>To have a broad view of our upcoming programmes, kindly click on 
                                    <a href="programmes.php" class="footer"><font color="brown"><b>Events and Calendar</b></font></a><BR/><BR/>Stay blessed in the Lord, Amen.</p>
                                    </div> 
                <div class="col-md-12">
                    <p style="background-color:#000; position: relative; top: 33px; width:80px;"><font color="#fff"><b>News Flash:</b></font></p><marquee behavior="scrol">A Day with the Lord annual programme will be coming up on June 18th-19th at CREM CATHEDRAL<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>
                    Also, OLORUN OLUNDADE PRAYER CONGRESS (quarterly prayer) will come up in this coming month of June 24th-26th at Erekusu Idande Prayer Mountain. Please let's endeavour to be there.<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>You can now send your Prayer request to this email:&nbsp;<i class="fa fa-envelope">&nbsp;creminternational@yahoo.com or contact our prayer line:</i> <i class="fa fa-phone">08033574655 OR 08076474324</i<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>Join hands in building a new auditorium to glorify God by donating into the church projects account.<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>You can also follow Daddy G.O on our Radio Special Programme both on Unique f.m and Ray f.m at 1:00pm - 1:15pm every Wednesday.<span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span><span class="fa fa-arrows"></span>Follow us on <i class="fa fa-twitter-square">&nbsp;Twitter(@CREMworlwide)</i> & <i class="fa fa-facebook-square">&nbsp;Facebook(cremworldwide)</i></marquee></b></div>
                       
                        </div> <!-- /.product-thumb -->
                            </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                <?php include './includes/side.php';?>
                    </div>
                </div>
            </div>
        </div>
    </div>                

    <div class="content-section" style="background-color: #2d3e50;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 section-title">
                    <h2></h2>
                </div> <!-- /.section -->
            </div> <!-- /.row -->
            <div class="row" style="background-color: #2d3e50;">
                <div class="col-md-3 col-sm-6">
                    <div class="product-holder">
                        <div class="product-item-2">
                            <div class="product-thumb">
                                <img src="images/images_2.jpg" alt="Product Title">
                            </div> <!-- /.product-thumb -->
                            <div class="product-content overlay">
                                <a>You can submit your Prayer request using our online support platform, believing that with God, all things are possible.</a><BR/>
                                <a href="prayer_request.php"><font color="#fff">PRAYER REQUEST ONLINE PLATFORM<BR/><i class="fa fa-envelope"></i> <a href="mailto:prayer-request@christredemptioninternational.org">prayer-request@christredemptioninternational.org</a></font></a>
                            </div> <!-- /.product-content -->
                        </div> <!-- /.product-item-2 -->
                    </div>
                    <div class="product-content">
                            <h5><a href="prayer_request.php">Prayer Request</a></h5>
                            
                        </div> <!-- /.product-content -->
                </div>
                <div class="col-md-3 col-sm-6">
                     <div class="product-holder">
                        <div class="product-item-2">
                            <div class="product-thumb">
                                <img src="images/images_3.jpeg" alt="Product Title">
                            </div> <!-- /.product-thumb -->
                            <div class="product-content overlay">
                                <a>Testify to the goodness of God. Share your testimony with us today to give strength to the weak, faith to the doubters, deliverance to those in bondage.</a>
                            </div> <!-- /.product-content -->
                        </div> <!-- /.product-item-2 -->
                    </div>
                    <div class="product-content">
                            <h5><a href="testimony.php">Testimony</a></h5>
                            
                        </div> <!-- /.product-content -->
                </div>
                <div class="col-md-3 col-sm-6">
                     <div class="product-holder">
                        <div class="product-item-2">
                            <div class="product-thumb">
                                <img src="images/image_5.jpg" alt="Product Title">
                            </div> <!-- /.product-thumb -->
                            <div class="product-content overlay">
                                <a>For God so loved the world that he gave his only begotten Son, that whosoever believeth in him, should not perish, but have everlasting life.<font color="#fff"><b>-John 3:16</b></font></a>
                            </div> <!-- /.product-content -->
                        </div> <!-- /.product-item-2 -->
                    </div>
                    <div class="product-content">
                            <h5><a href="#">Call to Salvation</a></h5>
                            
                        </div> <!-- /.product-content -->
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-holder">
                        <div class="product-item-2">
                            <div class="product-thumb">
                                <img src="images/images_6.jpg" alt="Product Title">
                            </div> <!-- /.product-thumb -->
                            <div class="product-content overlay">
                                <a><font color="#fff"><b>Malachi 3:10-</b></font>...and prove me now herewith, saith the LORD of hosts, if I will not open you the windows of heaven, and pour you out a blessing, that there shall not be room enough to receive it.</a>
                            </div> <!-- /.product-content -->
                        </div> <!-- /.product-item-2 -->
                    </div>
                    <div class="product-content">
                            <h5><a href="project.php">Donations</a></h5>
                            
                        </div> <!-- /.product-content -->
                </div>
                </div> <!-- /.col-md-3 -->
            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </div> <!-- /.content-section -->

    <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 section-title">
                    <h2>BOOKS</h2>
                </div> <!-- /.section -->
            </div> <!-- /.row -->
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <marquee direction="up" behavior="slide"><H2>COMING SOON...</H2><p>WRITTEN BY:Prophet T.O. Gabriel</p></marquee>
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-3 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/products/book0.png" alt="">
                        </div> <!-- /.product-thum -->
                        <div class="product-content">
                            <h5><font color="red"> IN HIS PRESENCE</font></h5>
                            <span class="tagline">By: Prophet T.O Gabriel</span>
                            
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-3 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/products/book1.png" alt="">
                        </div> <!-- /.product-thum -->
                        <div class="product-content">
                            <h5><font color="brown"> GOD IS HERE</font></h5>
                            <span class="tagline">By: Prophet T.O Gabriel</span>
                            
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-3 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/products/book2.png" alt="">
                        </div> <!-- /.product-thum -->
                        <div class="product-content">
                            <h5><font color="orange"> ANOINTING FOR SUCCESS</font></h5>
                            <span class="tagline">By: Prophet T.O Gabriel</span>
                            
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </div> <!-- /.content-section -->

    
        
        
<?php include './includes/footer.php';?>