<?php
	if(!isset($_GET['passkey']) || $_GET['passkey'] !== "merlin")
	{
		echo "error";
		die();
	}

	include("includes/config.php");

	Config::openDB();

	echo "<center><h2>Welcome to the indexer </h2></center>";

	echo "indexer is running";
	$excludedFiles = array("./search.php","./indexer.php");

	foreach (glob("./*.php") as $key => $title) {

		if(in_array($title, $excludedFiles))
			continue;

		$content = file_get_contents($title);
		// $content = preg_replace("\<", "", $content);

	// 	// $content = preg_replace("(<*>|</*>|<*/>)", "", $content);

		$text = htmlspecialchars($content);


		$text = str_replace("'", "", $text);



		mysql_query("INSERT INTO searchengine(pageurl, pagecontent) VALUES ('$title','$text')");
	}

	echo "<p>indexer is done</p>";
?>