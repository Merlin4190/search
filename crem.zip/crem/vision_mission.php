<?php
 $pageTitle = "Our Vision and Mission | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">
                        <h1 align="center"><img src="images/logo1.png"><br>
                        VISION<br><font face="Jokerman" size="4" color="red">(OUR VISION AND MISSION)</font></h1>
						<p align="justify" font size="4" color="white"><b><font size="15" face="freestyle script" color="#000">B</font>ringing many up unto the glory of God.&nbsp;
						<font color="#000">(Hebrew 2 : 10)</font> For it became him, for whom are all things and by whom are all things, in bringing many sons unto glory to make the captain of their salvation perfect through sufferings.</p>
						
						<h2 align="center"><font face="Jokerman" size="4" color="red">STATEMENT OF MISSION</font></h2>
						<p align="justify">To proclaim undiluted word of God in making disciple of All Nation for our Lord Jesus Christ. This is acheived by exalting God, encouraging believers, equipping Christians for the Ministry and evangelization of the whole world.</p>
						<h3 align="center"><font face="Jokerman" size="4" color="red">STATEMENT OF PURPOSE</font></h3>
						<p align="justify"><font size="15" face="freestyle script" color="#000">1.</font> To preach the word of God and lead men and women to becoming born again i.e. saved from sin, bondage to idolatory, false religion selfishness, corruption and all that prevent men and women from focusing eternity, through the knowledge of our lord Jesus Christ.</p>
						<p align="justify"><font size="15" face="freestyle script" color="#000">2.</font> To demosntrate practical Christianity by our daily life to show that it is possible to live like our lord and Saviour Jesus Christ.</p>
						<p align="justify"><font size="15" face="freestyle script" color="#000">3.</font> To demonstrate the power in the name of Jesus by leading men and women, old and young to work in dominion over every demonic influence and power through the supernatural power of God.</p><p><font size="15" face="freestyle script" color="#000">4.</font> To train and equip men and women to fulfill the great commission of evangelizing the world for Christ.</p>
						<p align="justify"><font size="15" face="freestyle script" color="#000">5.</font>To plant Churches throughout the world before our Lord returns beginning from Osogbo and widening there from in ripples through Osun State, Nigeria, Africa and the World.</p>
						<p align="justify"><font size="15" face="freestyle script" color="#000">6.</font>To prepare men and women without sport or wrinkle for the glorious appearing of our Lord from heaven.</p>
						<p align="justify"><font size="15" face="freestyle script" color="#000">7.</font>To do all such other things that are incidental or conductive to the attainment</font> of the objectives mentioned above.</p>
       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="product-item">
                        <div class="product-thumb">
                            <img src="images/revelation.jpg" alt="">
                            <img src="images/signs.jpg" alt="">
                            <label for="username" class="control-label">Daily Editorial</label>
                            <input type="text" class="form-control email-form" placeholder="Subscribe(E-mail)"><input type="submit" name="Send" value="Send" id="searchbutton" title="Send" class="btn btn-default btn-submit"  /><BR/>
                            <label for="username" class="control-label">Prayer Request</label>
                            <textarea rows="1" cols="27" class="message-form"></textarea>
                            <button type="submit" class="btn btn-default btn-submit">Submit</button>
                        </div> <!-- /.product-thum -->
                    </div> <!-- /.product-item -->
                </div> <!-- /.col-md-3 -->
            </div>
        </div>
</div>


        
<?php include './includes/footer.php';?>