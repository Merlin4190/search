<?php
 $pageTitle = "Live Blog | Christ Redemption International";

include("includes/header.php");

?>

<section id="gallery" class="parallax-section">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                <h1 class="heading">Live Blog</h1>                
            </div>
            <div class="clearfix"></div>
            
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.3s">
                <a href="images/gallery-img1.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img1.jpg" alt="gallery img"></a>
                <div>
                    <h3>Great Expectations! </h3>
                    <span><p align="justify">This signs shall follow them that believed- they shall operate in the supernatural power of God to wrought great signs and wonders; deliver the sick, set the captives free; recovery of sight to the blind, enjoy eternal security. People will be delivered from spiritual blindness, the sick will receive healing from their diseases, and many people will experience great deliverance from the afflictions of the devil: There will be supernatural abundance that destroys poverty and lack. There will be great change of stories from barreness to fruitfulness, failure to deprive favour; shame to fame, long time afflictions shall turn to sudden positive testimony and there shall be showers of all round blessings as people possess their possessions. The supernatural anointing of Calvary will destroy yokes of failure, disappointment, ancestral powers and curses of household enemies. There will be total recovery, refreshment and victory over the works of the devil as songs of joy fills the heart of everyone that participates in this divine programme.
                    Don't stay behind, it's your appointed that you have been waiting, Jesus the miracle working God is awaiting. God in His great mercy has prepared me and fellow anointed men & women of God to be used.
                    Remain blessed as we meet at this great event.</p>
                    <div style="text-align: right; font-weight: bold">
                            <em>
                            You are wonderfully blessed<br/>
                                Prophet T. Gabriel                               
                            </em>
                        </div>
                    </span>
                </div>
                <a href="images/gallery-img2.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img2.jpg" alt="gallery img"></a>
                <div>
                    <h3>JPF 2016 Programme</h3>
                    <span>
                    <h5 style="background-color: #2a80b9;">Monday 3rd October.</h5>
                    <div class="table-responsive">
								<table class="table">
									<thead>
										<tr>
											<th>PROGRAMMES</th>
											<th>TIME</th>																			
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Morning of Glory</td>
											<td bgcolor="red" style="color: yellow">6.00am</td>										
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Grand Opening</td>
											<td bgcolor="red" style="color: yellow">4.00pm</td>
										</tr>
									</tbody>						
									</table>
					<h5 style="background-color: #2a80b9;">Tuesday 4th October.</h5>
								<table class="table">
									<thead>
										<tr>
											<th>PROGRAMMES</th>
											<th>TIME</th>																			
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Signs and Wonders Morning</td>
											<td bgcolor="red" style="color: yellow">6.00am</td>										
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Morning Plenary Session</td>
											<td bgcolor="red" style="color: yellow">10.00am-12.00pm</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Message/Teaching</td>
											<td bgcolor="red" style="color: yellow">3.00pm-4.00pm</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Evening of Signs and Wonders Crusade</td>
											<td bgcolor="red" style="color: yellow">6.00pm</td>
										</tr>
									</tbody>						
									</table>
					<h5 style="background-color: #2a80b9;">Wednesday 5th October.</h5>
								<table class="table">
									<thead>
										<tr>
											<th>PROGRAMMES</th>
											<th>TIME</th>																			
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Morning of Signs and Wonders</td>
											<td bgcolor="red" style="color: yellow">6.00am</td>										
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Destroy of Embargo</td>
											<td bgcolor="red" style="color: yellow">6.00am</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Message/Prayer Power in His word</td>
											<td bgcolor="red" style="color: yellow"></td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>God of all Flesh</td>
											<td bgcolor="red" style="color: yellow">12.00pm-3.00pm</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Evening of Signs and Wonders</td>
											<td bgcolor="red" style="color: yellow">5.00pm</td>
										</tr>
									</tbody>						
									</table>
							</div>		
                    </span>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <a href="images/gallery-img3.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img3.jpg" alt="gallery img"></a>
                <div>                                               
                <h3>Post-Live Streaming</h3>
                <BR/>
                    <div class="liveblog">
                        	<video  loop class="embed-responsive-item" controls>
                                <source src="videos/children.mp4" type="video/mp4" />
                                
                                Your browser does not support the video tag.
                            </video>
                            

                        </div>
                        <BR/>
                    <div class="liveblog">
                        	<video  loop class="embed-responsive-item" controls>
                                <source src="videos/children.mp4" type="video/mp4" />
                                
                                Your browser does not support the video tag.
                            </video>
                            

                        </div>
                        <h3><u>Live Updates</u></h3>
                </div>
                
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.9s">
                <a href="images/gallery-img4.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img4.jpg" alt="gallery img"></a>
                <div>
                    <h3>JPF 2016 Programme</h3>
                    <span>
                    <h5 style="background-color: #2a80b9;">Thursday 6th October.</h5>
                    <div class="table-responsive">
								<table class="table">
									<thead>
										<tr>
											<th>PROGRAMMES</th>
											<th>TIME</th>																			
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Morning of Signs and Wonders</td>
											<td bgcolor="red" style="color: yellow">6.00am</td>										
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Seminar/Teaching<br/><b>Power as of Old</b></td>
											<td bgcolor="red" style="color: yellow">10.00-12.00am</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Who qualifies to manifest the sign</td>
											<td bgcolor="red" style="color: yellow">2-3.00pm</td>										
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Signs & Miracle Rally</td>
											<td bgcolor="red" style="color: yellow">5.00pm</td>										
										</tr>
									</tbody>						
									</table>
					<h5 style="background-color: #2a80b9;">Friday 7th October.</h5>
								<table class="table">
									<thead>
										<tr>
											<th>PROGRAMMES</th>
											<th>TIME</th>																			
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Morning of Open Heaven</td>
											<td bgcolor="red" style="color: yellow">6.00am</td>										
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Message/Prayer<br/><b>I Will Fulfill My Purpose</b></td>
											<td bgcolor="red" style="color: yellow">9-11.00pm</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Divine Healing</td>
											<td bgcolor="red" style="color: yellow">2-3.00pm</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Bible Study</td>
											<td bgcolor="red" style="color: yellow">4.00pm</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Signs and Wonders Family (Couple)<br/><b>Night of Signs and Manifestation</b></td>
											<td bgcolor="red" style="color: yellow">10.00pm</td>
										</tr>
									</tbody>						
									</table>					
							</div>		
                    </span>
                </div>
                <a href="images/gallery-img5.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img5.jpg" alt="gallery img"></a>
                <div>
                    <h3>JPF 2016 Programme</h3>
                    <span>
                    <h5 style="background-color: #2a80b9;">Saturday 8th October.</h5>
                    <div class="table-responsive">
								<table class="table">
									<thead>
										<tr>
											<th>PROGRAMMES</th>
											<th>TIME</th>																			
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>He is Faithful</td>
											<td bgcolor="red" style="color: yellow">10.00am</td>										
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>Seminar/Teaching<br/><b>Bible Study</b></td>
											<td bgcolor="red" style="color: yellow">12.00noon</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>It is your appointed time</td>
											<td bgcolor="red" style="color: yellow">3.00pm</td>										
										</tr>
									</tbody>															
									</table>
					<h5 style="background-color: #2a80b9;">Sunday 9th October.</h5>
								<table class="table">
									<thead>
										<tr>
											<th>PROGRAMMES</th>
											<th>TIME</th>																			
										</tr>
									</thead>
									<tbody>
										<tr>
											<td><b>Go and Manifest the Signs</b></td>
											<td bgcolor="red" style="color: yellow"></td>										
										</tr>
									</tbody>															
									</table>					
							</div>
							<ul class="pagination pagination-lg">
                            <li><a href="live_blog_day1.php">DAY1</a></li>
                            <li><a href="live_blog_day2.php">DAY2</a></li>
                            <li><a href="live_blog_day3.php">DAY3</a></li>
                            <li><a href="live_blog_day4.php">DAY4</a></li> 
                            <li><a href="live_blog_day5.php">DAY5</a></li> 
                            <li class="disabled"><a href="#">DAY6</a></li> 
                            <li><a href="live_blog_day7.php">DAY7</a></li>   
                            </ul>		
                    </span>
                </div>
            </div>
        </div>
    </div>
</section>


<div class="content-section" style="background-color: #2d3e50;">
       			<div class="container">                    
            		<div class="row">
                    	<div class="col-md-12 col-sm-6">
                    		<div class="product-holder">
                    <font color="#fff"><marquee direction="right" behavior="slide"><h4"> NOW AVAILABLE IN OUR STORE... </h4></marquee>
                    <div class="col-md-2 col-sm-2"><a href="payment.php"><img src="images/book.png"></a><p>Christian Books</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/steaker.jpg"></a><p>Stickers</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/calendar.jpg"></a><p>Calendars</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/disck.jpg"></a><p>Audio and Video Messages</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/bkk.jpg"></a><p>Motivational Books</p></div>
					<div class="col-md-2 col-sm-6"><a href="#.php"><img src="images/sundaysch.jpg"></a><p>Sunday School Manual</p></div></font>
							</div>
						</div>
					</div>
				</div>
			</div>

<?php include './includes/footer.php';?>