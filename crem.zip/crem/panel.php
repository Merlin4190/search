<?php
 $pageTitle = "Panel | Christ Redemption International";
 require_once('includes/config.php');
 //if not logged in redirect to login page
if(!$user->is_logged_in()){ header('Location: admin/login.php'); }

include("includes/header.php");

?>

<div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                    <h1 style="text-align: left;"><a href="./admin/index.php">Panel Index</a></h1>
                    <hr / style="width: 100%;">
                    	<h2>SIDE MENU EDITORIAL SUBSCRIPTION</h2>

						<div class="table-responsive">

                    <table class="table">
                    <thead>
                    	<tr>
							<th><font face="Arial, Helvetica, sans-serif">E-mails</font></th>
						</tr>
					</thead>

<?php

$user="root";
$password="";
$database="christr4_crem";

mysql_connect("localhost",$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM editorial2";
$result=mysql_query($query);

$num=mysql_numrows($result);

mysql_close();



$i=0;
while ($i < $num) {

$mail=mysql_result($result,$i,"mail");


?>

<tr>
<td><font face="Arial, Helvetica, sans-serif"><a href="mailto:<?php echo $mail; ?>"><?php echo $mail; ?></a></font></td>
</tr>


<?php

$i++;
}
echo "</table>";
?>
</div>

<BR/>
<BR/>
<h2>FOOTER MENU EDITORIAL SUBSCRIPTION</h2>

						<div class="table-responsive">

                    <table class="table">
                    <thead>
                    	<tr>
							<th><font face="Arial, Helvetica, sans-serif">E-mails</font></th>
						</tr>
					</thead>

<?php

$user="root";
$password="";
$database="christr4_crem";

mysql_connect("localhost",$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM editorial";
$result=mysql_query($query);

$num=mysql_numrows($result);

mysql_close();



$i=0;
while ($i < $num) {

$email=mysql_result($result,$i,"email");


?>

<tr>
<td><font face="Arial, Helvetica, sans-serif"><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></font></td>
</tr>


<?php

$i++;
}
echo "</table>";
?>
</div>
<BR/>
<BR/>
<h2>SIDE MENU PRAYER REQUEST</h2>

						<div class="table-responsive">

                    <table class="table">
                    <thead>
                    	<tr>
							<th><font face="Arial, Helvetica, sans-serif">REQUEST MESSAGE</font></th>
						</tr>
					</thead>

<?php

$user="root";
$password="";
$database="christr4_crem";

mysql_connect("localhost",$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM request2";
$result=mysql_query($query);

$num=mysql_numrows($result);

mysql_close();



$i=0;
while ($i < $num) {

$message2=mysql_result($result,$i,"message2");


?>

<tr>
<td><font face="Arial, Helvetica, sans-serif"><?php echo $message2; ?></a></font></td>
</tr>


<?php

$i++;
}
echo "</table>";
?>
</div>
<BR/>
<BR/>
<h2>PRAYER REQUEST</h2>

						<div class="table-responsive">

                    <table class="table">
                    <thead>
                    	<tr>
							<th><font face="Arial, Helvetica, sans-serif">NAME</font></th>
							<th><font face="Arial, Helvetica, sans-serif">E-mail</font></th>
							<th><font face="Arial, Helvetica, sans-serif">SUBJECT</font></th>
							<th><font face="Arial, Helvetica, sans-serif">MESSAGE</font></th>
						</tr>
					</thead>

<?php

$user="root";
$password="";
$database="christr4_crem";

mysql_connect("localhost",$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM request";
$result=mysql_query($query);

$num=mysql_numrows($result);

mysql_close();



$i=0;
while ($i < $num) {
$name=mysql_result($result,$i,"name");
$email2=mysql_result($result,$i,"email2");
$subject=mysql_result($result,$i,"subject");
$message=mysql_result($result,$i,"message");


?>

<tr>
<td><font face="Arial, Helvetica, sans-serif"><?php echo $name; ?></a></font></td>
<td><font face="Arial, Helvetica, sans-serif"><a href="mailto:<?php echo $email2; ?>"><?php echo $email2; ?></a></font></td>
<td><font face="Arial, Helvetica, sans-serif"><?php echo $subject; ?></a></font></td>
<td><font face="Arial, Helvetica, sans-serif"><?php echo $message; ?></a></font></td>
</tr>


<?php

$i++;
}
echo "</table>";
?>
</div>
<BR/>
<BR/>
<h2>TESTIMONIES</h2>

						<div class="table-responsive">

                    <table class="table">
                    <thead>
                    	<tr>
							<th><font face="Arial, Helvetica, sans-serif">NAME</font></th>
							<th><font face="Arial, Helvetica, sans-serif">E-mail</font></th>
							<th><font face="Arial, Helvetica, sans-serif">SUBJECT</font></th>
							<th><font face="Arial, Helvetica, sans-serif">MESSAGE</font></th>
						</tr>
					</thead>

<?php

$user="root";
$password="";
$database="christr4_crem";

mysql_connect("localhost",$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM testimony";
$result=mysql_query($query);

$num=mysql_numrows($result);

mysql_close();



$i=0;
while ($i < $num) {
$name1=mysql_result($result,$i,"name1");
$email3=mysql_result($result,$i,"email3");
$subject1=mysql_result($result,$i,"subject1");
$message1=mysql_result($result,$i,"message1");


?>

<tr>
<td><font face="Arial, Helvetica, sans-serif"><?php echo $name1; ?></a></font></td>
<td><font face="Arial, Helvetica, sans-serif"><a href="mailto:<?php echo $email3; ?>"><?php echo $email3; ?></a></font></td>
<td><font face="Arial, Helvetica, sans-serif"><?php echo $subject1; ?></a></font></td>
<td><font face="Arial, Helvetica, sans-serif"><?php echo $message1; ?></a></font></td>
</tr>


<?php

$i++;
}
echo "</table>";
?>


				</div>
					</div>
						</div>


<?php include './includes/side.php';?>

</div>
    </div>
		</div>
           

<?php include './includes/footer.php';?>