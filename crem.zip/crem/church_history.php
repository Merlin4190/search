<?php
 $pageTitle = "Church History | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">
                        	<h5><font color="brown"><b>THE CHURCH AND HER PASTOR</b></font></h5>
							<p align="justify">The founding pastor and the General Overseer of the Church and Ministry is Pastor/Prophet Tilufoye Olaitan Ojediran Gabriel, who was ordained a minister of God in <font color="blue">1989.</font> Born in the traditional town of Ede in Osun State into a Muslim family, Pastor Gabriel had a broad based training in core theology and various aspects of evangelism and church planting all of which God has used to prepare him for the task of presiding over a church. A dogged, fearless and consummate minister of the Gospel with penchant for hard work even when conditions are hostile; and a deep lover of people, Pastor Gabriel had in the early stages of his calling, ministered to and touched several souls as a Prophet and an Evangelist in many churches across the country, reaching as far as Sokoto in Sokoto State in the early <font color="blue">80s.</font> In Sokoto, God used him elsewhere in very unique ways. There were unusual deliverances and breakthroughs coming with his ministrations. Here apart from ministering deliverance and salvation of souls, the Pastor mentored many young people into the Ministry. Many of these men and women have excelled and become great ministers of God. It was here the Pastor met <font color="blue">Pa I. Ajayi,</font> who is now the Baba Ijo of the church. Pastor Gabriel led a corps of spiritually thirsty men and women who wanted to make a difference in the faith as vibrant, gospel believing individuals into a new movement. These men and women formed the foundation of the church that we have today to the glory of God Almighty.<br><br>The beginning of the church was far from being smooth. It posed considerable challenges of all sorts and it was only his grace that set us on course. There were questionsn begging for answers:<br>How would it be interpreted if a church was started given the fact that the set man as well as many of the pioneering members were notable figures in their mother churches?<br>Where would the resources needed to start the church come from?<br>Where would capable men and women for the ministry come from to support the set man in the expanding ministry?<br>These and many other questions kept coming. However, after a period of waiting and prayers, assurances from the Master came and bold steps were taken to start the church. Like it was for Moses as contained in <font color="green"><b>Exodus 33:13-14,</b></font> God was at the centre of the project and His assurance that He would go with His church energized the founding members into a life of total commitment to starting the Church. At various stages the Lord raised many experienced men and women for the Ministry to support His servant. While we must give all glory to God the Almighty, this account would be incomplete without recalling the support of persons like<br><font color="blue"><b>Professors Alfred Adewuyi and Olubodun Ayeni during the early years.<br>The Olaaresa of Masifa, Osun State,<br>Oba (Pastor) Matthew Oyekale,</b></font> among several others was also always around to support the church. Besides these were several young Pastors and Evangelists who were working with Pastor Gabriel before the Ministry became independent and a full fledge Church. May the Lord bless and sustain all of these men wherever they are today in Jesus'Name. Amen.<br><br>Of course, the fears expressed at the beginning were well founded. There were dare needs for the teeming population of a church that was essentially grassroots-based. There was a neeed for a auditorium for worship, vehicles to convey people to and fro the church, essential items for evangelism and security of the few items the church had among others. In His own ways and timeline God met all of these needs. HE has been to the church a true God of Signs and Wonders and the Church remains grateful for His faithfulness.
                            <ul class="pagination pagination-lg">
                            <li  class="disabled"><a href="#">1</a></li>
                            <li><a href="church_history_page2.php">2</a></li>
                            <li><a href="church_history_page3.php">3</a></li>  
                            </ul>
                        
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>