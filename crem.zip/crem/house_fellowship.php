<?php
 $pageTitle = "House Cells | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br>HOUSE CELLS<br></h1>
                        	<h2>Osogbo</h2>
							<div class="table-responsive">
								<table class="table">
									<thead>
										<tr>
											<th>#</th>
											<th>Zone</th>
											<th>Venue</th>
											<th>Officiating Minister</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>1</td>
											<td>Ogo-oluwa</td>
											<td>Mrs Adebayo's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>2</td>
											<td>Owode, Ede</td>
											<td>Deacon Amusan's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>3</td>
											<td>Ido-Osun</td>
											<td>Pastor Olayiwola's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>4</td>
											<td>Offatedo</td>
											<td>Pastor Gbenga's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>5</td>
											<td>Oke-Ayo</td>
											<td>Pastor Isiah's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>6</td>
											<td>Mallam Tope/Goshen's</td>
											<td>Brother Akinloye's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>7</td>
											<td>Agunbelewo/Okinni</td>
											<td>Deacon Thomas' House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>8</td>
											<td>Oke-Oniti</td>
											<td>Deaconess Lanlehin's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>9</td>
											<td>Obelawo</td>
											<td>Pastor Thomas House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>10</td>
											<td>Odi-Olowo</td>
											<td>Pastor Oyeniran's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>11</td>
											<td>Oke-Ayepe/Ilesa Garage</td>
											<td>Pastor Bolanle's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>12</td>
											<td>Ile-Idande/Housing Estate</td>
											<td>Deacon Olonilua House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>13</td>
											<td>Ile-Idande</td>
											<td>Brother Ajani's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>14</td>
											<td>Olude</td>
											<td>Deacon Ogunshina's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>15</td>
											<td>Rinsayo/Halleluia</td>
											<td>Deaconess Ojulari's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>16</td>
											<td>Agowande/Oju Irin</td>
											<td>Deacon Adegoke's House</td>
										</tr>
									</tbody>
									<tbody>
										<tr>
											<td>17</td>
											<td>Ota-efun</td>
											<td>Deaconess Osun House</td>
										</tr>
									</tbody>
								</table>
								
							</div>
						


       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>