<?php
 $pageTitle = "Photos | Christ Redemption International";

include("includes/header.php");

?>

<div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br>PHOTO GALLERY</h1>
                        <div class="footer-widget">
                            <h3 class="widget-title">PHOTO Links</h3>
                            <strong><ul style="list-style-type: square;">
                                <li><a href="photos_memories.php">MEMORIES</a></li>
                                <li><a href="photos_day_with_the_lord.php">A DAY WITH THE LORD 2016</a></li>
                                <li><a href="photos_oludande.php">OLUDANDE PRAYER CONGRESS 2016</a></li>                                
                                <li><a href="photos_childrensconference.php">CHILDREN'S ANNUAL CONFERENCE 2016</a></li>
                                <li><a href="photos_youthconference.php">CREM YOUTH CONFERENCE 2016</a></li>
                                <li><a href="photos_excellentwomen.php">EXCELLENT WOMEN CONVENTION 2016</a></li>
                                <li><a href="photos_mensconference.php">MEN'S ANNUAL CONFERENCE 2016</a></li>
                                <li><a href="photos_jpf.php">JESUS POWER FESTIVAL 2016</a></li>
                            </ul></strong>
                        </div> <!-- /.footer-widget -->

                        



                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>