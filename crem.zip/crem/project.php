<?php
 $pageTitle = "Projects | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br>
						DONATIONS</h1><br>
						<p align="justify"><b>God bless you as you take the pain to visit this section of the website.</b></p>
						<h2> Ongoing Projects:</h2>
							<ul>
								<li>New Church Auditorium (CREM CATHEDRAL)</li>
									<p align="justify"> God is interested in people who will build His house like Nehemiah and Solomon did (Neh 8:1-15). With many new belivers and increasing congregation, there is a huge and ever-growing need for buildings to serve as a sanctuaary of a hope, a beacon of light and to bring belivers closer to the presence of God.</p></ul>
									<h4>Why Build?</h4>
									<p align="justify">We build because our motivation for the work is that God may be glorified.</p>
									<p align="justify">To join hands in building a new auditorium to glorify God, Kindly make payments at:<br>
									<font color="green"><b>Name of Bank: First Bank Nigeria Plc<br>Account Name: Christ Redemption Ministry<br>Account No: 2009424300</b></font></p>
									<p>For further enquiries: Contact <i class="fa fa-phone">08033574655</i></p>
							<ul>
								<li>Excellent Women Maternity Centre</li>
									<p align="justify">In a bid to improve the welfare condition of Pregnant Women in attaining safe birth condition, the Church has placed in her plans to build a standard maternity center with the following aims:<br>
									1. Monitoring the physical, psychological, and social well-being of the mother through out the childbearing cycle<br>2. Providing the mother with individualised education, counseling, and prenatal care, continous hands-on assistance during labor and delivery, and postpartum support<br>
									3. Minimising technological interventions <br>4. Identifying and referring women who require obstetrical attention.<br></p></ul>
									<p align="justify">To be part of this wonderful initiative, Kindly donate at:</p>
									<p align="justify"><font color="green"><b>Name of Bank: First Bank Nigeria Plc</p.Account Name: Christ Redemption Ministry<br>Account No: 2009424300<br></b></font>
									<p align="justify">For further enquiries: Contact <i class="fa fa-phone">08033574655</i>s</p>
									<h3>Other Ongoing Projects:</h3>
							<ul>
								<li>Redesigning and the Renovation of the old Church into a Guest house</li>
								<li>Construction of a permanent site for Mount Zion Group of Schools</li>
								<li>Church building at the Prayer Mountain</li>
							</ul>
									<p align="justify">To invest in God's Work, Kindly make payment at:</p><font color="green"><b>Name of Bank: First Bank Nigeria Plc<br>Account Name: Christ Redemption Ministry<br>Account No: 2009424300</b></font></p>
									<p align="justify">For further enquiries: Contact <i class="fa fa-phone">08033574655</i></p>
									<p align="justify">Also, watch out for the following new projects in a bid to continue the good work of God and fostering the spreading of the Gospel through Jesus Christ our Saviour</p>
									<h2>New Projects:</h2>
							<ul>
								<li>Construction of a storey building Permanent Secretariat at Headquarter</li>
								<li>Building of Ministers' Estate</li>
								<li>Christ Redemption Miracle Camp Site</li></ul>
								<p align="justify">Likewise, for the payment of tithes and offerings using the bank outlets:<br><font color="green"><b>Name of Bank: First Bank Nigeria Plc<br>Account Name: Christ Redemption Ministry<br>Account No: 2002240985</b></font></p>
								<p align="justify">For further enquiries: Contact <i class="fa fa-phone">08033574655</i></p>



       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>