<?php
 $pageTitle = "Church Structure | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">

                        <h1 align="center"><img src="images/logo1.png"><br>
						CHURCH STRUCTURE<br></h1><br>
						<h2><font face="Jokerman" color="#000">BOARD OF TRUSTEES</font></h2>
						<p>Prophet Pastor Tilufoye Olaitan Gabriel Founding President and General Overseer<br>
						<i class="fa fa-phone">&nbsp;08033574655</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:prophetogabriel@yahoo.com"><b>prophetogabriel@yahoo.com</b></a></i></p>
						<p>Pastor Francis Adesina Deputy General Overseer and Board of Trustees Member<br><i class="fa fa-phone">&nbsp;08037193141</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:faadesin@yahoo.com"><b>faadesin@yahoo.com</b></a></i></p>
						<p>Professor Pastor Olu Olatubara Assistant General Overseer (Mission and Evangelism) and Board of Trustees Member<br><i class="fa fa-phone">&nbsp;08053851855</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:coolatubara@yahoo.com"><b>coolatubara@yahoo.com</b></a></i></p>
						<p>Lady Evangelist Comfort Gabriel Ojediran Wife of the General Overseer, Excellent Women President and Board of Trustees Member<br><i class="fa fa-phone">&nbsp;08167744992</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Adeleke Aladegbemi Director, Mission and Evangelism and Board of Trustees Member<br><i class="fa fa-phone">&nbsp;08023230592</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>

						<h2><font face="Jokerman" size="4" color="#000">EXECUTIVE BOARD</font></h2>
						<p>Prophet Pastor Tilufoye Olaitan Gabriel Founding President and General Overseer<br>
						<i class="fa fa-phone">&nbsp;08033574655</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Francis Adesina Deputy General Overseer and Member of Executive Board<br>
						<i class="fa fa-phone">&nbsp;08037193141</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:faadesin@yahoo.com"><b>faadesin@yahoo.com</b></a></i></p>
						<p>Professor Pastor Olu Olatubara Assistant General Overseer (Mission and Evangelism) and Member of Executive Board<br><i class="fa fa-phone">&nbsp;08053851855</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:coolatubara@yahoo.com"><b>coolatubara@yahoo.com</b></a></i></p>
						<p>Lady Evangelist Comfort Gabriel Ojediran Wife of the General Overseer, Excellent Women President and Member of Executive Board<br><i class="fa fa-phone">&nbsp;08167744992</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Adeleke Aladegbemi Director, Mission and Evangelism and Member of Executive Board<br>
						<i class="fa fa-phone">&nbsp;08023230592</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Ayodele Lateef Ajao Assistant General Overseer (General Services) and Member of Executive Board<br>
						<i class="fa fa-phone">&nbsp;08134574282</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:ajaoayodele3@gmail.com"><b>ajaoayodele3@gmail.com</b></a></i></p>
						<p>Pastor Gabriel Ajibola Thomas Assistant General Overseer (Finance and Personnel) and Member of Executive Board<br><i class="fa fa-phone">&nbsp;08034893502</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:boladeye@yahoo.com"><b>boladeye@yahoo.com</b></a></i></p>
						<p>Pastor Engineer Gbodi Joshua Secretary-General and Member of Executive Board<br>
						<i class="fa fa-phone">&nbsp;08033811236</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:gbodiji@yahoo.com"><b>gbodiji@yahoo.com</b></a></i></p>

						<h3><font face="Jokerman" size="4" color="#000">BOARD OF PASTORS'</font></h3>
						<p>Prophet Pastor Tilufoye Olaitan Gabriel Founding President and General Overseer<br>
						<i class="fa fa-phone">&nbsp;08033574655</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Francis Adesina Deputy General Overseer and Member, Board of Pastors'<br>
						<i class="fa fa-phone">&nbsp;08037193141</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:faadesin@yahoo.com"><b>faadesin@yahoo.com</b></a></i></p>
						<p>Professor Pastor Olu Olatubara Assistant General Overseer (Mission and Evangelism) and Member, Board of Pastors'<br><i class="fa fa-phone">&nbsp;08053851855</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:coolatubara@yahoo.com"><b>coolatubara@yahoo.com</b></a></i></p>
						<p>Lady Evangelist Comfort Gabriel Ojediran Wife of the General Overseer, Excellent Women President and Member, Board of Pastors'<br><i class="fa fa-phone">&nbsp;08167744992</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Adeleke Aladegbemi Director, Mission and Evangelism and Member, Board of Pastors'<br>
						<i class="fa fa-phone">&nbsp;08023230592</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Ayodele Lateef Ajao Assistant General Overseer (General Services) and Member, Board of Pastors'<br>
						<i class="fa fa-phone">&nbsp;08134574282</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:ajaoayodele3@gmail.com"><b>ajaoayodele3@gmail.com</b></a></i></p>
						<p>Pastor Gabriel Ajibola Thomas Assistant General Overseer (Finance and Personnel) and Member, Board of Pastors'<br><i class="fa fa-phone">&nbsp;08034893502</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:boladeye@yahoo.com"><b>boladeye@yahoo.com</b></a></i></p>
						<p>Pastor Engineer Gbodi Joshua Secretary-General and Member, Board of Pastors'<br>
						<i class="fa fa-phone">&nbsp;08033811236</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:gbodiji@yahoo.com"><b>gbodiji@yahoo.com</b></a></i></p>
						<p>Pastor M.A. Bolanle Director of Finance<br><i class="fa fa-phone">&nbsp;08100278419</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:bolanlemustafa@gmail.com"><b>bolanlemustafa@gmail.com</b></a></i></p>
						<p>Pastor Yemi Ogundipe Director, Bible Study and Research<br><i class="fa fa-phone">&nbsp;08033511747</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:yemanpe@yahoo.com"><b>yemanpe@yahoo.com</b></a></i></p>
						<p>Pastor Rufus Adeeyo Director, Men Affairs<br><i class="fa fa-phone">&nbsp;08033913349</i>&nbsp;<i class="fa fa-envelope"></i></p>
						<p>Pastor Gabriel Taiwo Director, Intercession and Prayer Mountain<br><i class="fa fa-phone">&nbsp;08188572176</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Balogun <br><i class="fa fa-phone">&nbsp;08066552728</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Engineer Odeyemi Director, Technical Services<br>
						<i class="fa fa-phone">08033880542</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Olayiwola B.K. Director of Works and Physical Planning<br><i class="fa fa-phone">&nbsp;07039169371</i>&nbsp;<i class="fa fa-envelope">&nbsp;<a href="mailto:olayiwolabibitayokunle@yahoo.com"><b>olayiwolabibitayokunle@yahoo.com</b></a></i></p>
						<p>Pastor Gbenga Fayemiwo Director of Publications and Public Relations<br><i class="fa fa-phone">&nbsp;07035591289</i>&nbsp;<i class="fa fa-envelope">&nbsp;</i></p>
						<p>Pastor Oyeniran Folorunsho Director, Ushering, Counselling and Visitation<br><i class="fa fa-phone">&nbsp;07035591289</i>&nbsp;<i class="fa fa-envelope"><a href="mailto:Hope4god@yahoo.com">&nbsp;<b>Hope4god@yahoo.com</b></a></i></p>

						<h4><font face="Jokerman" size="4" color="#000">DEPARTMENTS</font></h4>
						<ul>
						<li><b>FINANCE</b></li><br>Pastor Bolanle M.A.-Director <i class="fa fa-phone">08100278419</i><br><br>
						<li><b>BIBLE STUDY AND RESEARCH</b></li><br>Pastor Yemi Ogundipe-Director <i class="fa fa-phone">08033511747</i><br><br>
						<li><b>MEN AFFAIRS</b></li><br>Pastor Rufus Adeeyo-Director <i class="fa fa-phone">08033913349</i><br><br>
						<li><b>INTERCESSION AND PRAYER MOUNTAIN</b></li><br>Pastor Gabriel Taiwo-Director <i class="fa fa-phone">08188572176</i><br><br>
						<li><b>TECHNICAL SERVICES</b></li><br>Pastor Engineer Odeyemi-Director <i class="fa fa-phone">08033880542</i><br><br>
						<li><b>PHYSICAL PLANNING AND WORKS</b></li><br>Pastor Olayiwola B.K.-Director <i class="fa fa-phone">07039169371</i><br><br>
						<li><b>PUBLICATIONS AND PUBLIC RELATIONS</b></li><br>Pastor Gbenga Fayemiwo-Director <i class="fa fa-phone">07035591289</i><br><br>
						<li><b>USHERING, COUNSELLING AND VISITATION</b></li><br>Pastor Oyeniran Folorunsho-Director <i class="fa fa-phone">07035591289</i><br><br>
						<li><b>MUSIC AND DRAMA</b></li><br>Pastor Caleb Ojediran-Director <i class="fa fa-phone">08062815649</i><br><br>
						<li><b>ENVIRONMENTAL SERVICES</b></li><br>Pastor (Dr.) Wole Fabiyi-Director <i class="fa fa-phone">08034702457</i><br><br>
						<li><b>WELFARE, EMERGENCY AND RELIEF</b></li><br>Pastor (Dr.) Segun Olaogun-Director <i class="fa fa-phone">08034232163</i><br><br>
						<li><b>YOUTH AFFAIRS</b></li><br>Pastor F. Gabriel Oluwagbemiga-Director <i class="fa fa-phone">08060321533</i><br><br>
						<li><b>WOMEN AND CHILDREN AFFAIRS</b></li><br>Lady Evangelist Ajao-Director <i class="fa fa-phone">08035306401</i><br><br>
						<li><b>PERSONAL AND LEGAL MATTERS</b></li><br>Assistant Pastor Gbenga-Director <i class="fa fa-phone">080</i><br><br>
						<li><b>AUDITS</b></li><br>Lady Evangelist Ifeoluwa Ojediran-Director <i class="fa fa-phone">08060321533</i><br><br>
						<li><b>CHURCH PLANTING</b></li><br>Pastor Victor Akinwale-Director <i class="fa fa-phone">08033270312</i><br><br>
						<li><b>SECURITY SERVICES</b></li><br>Pastor J.A. Akinlabi  <i class="fa fa-phone">08034094057</i><br><br>
						<li><b>MISSION AND EVANGELISM</b></li><br>Pastor Adeleke Aladegbemi<i class="fa fa-phone">08023230592</i><br><br></font></ul>



       
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>