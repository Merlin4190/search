<?php
 $pageTitle = "Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">
                        <img src="images/sundayschool.jpg" alt="Product Title" class="GO">
                            <p align="center"><img src="images/logo1.png"></p><p align="justify">I welcome you to the <font color="green">2014 edition</font> of our Sunday School Series. As you know, the Sunday School is important for the growth and development of a Christian. It is one of the proven strategies by which we can understand deeper, the mind of God as enshrined in the Scriptures on vaious issues touching our well being. It thus, offers an invaluable opportunityt for the Christian to draw closer to God.<br><b>Punctuality and regularity</b> in the Sunday School sessions are very important. The class leader would maintain a registerto help him/her to monitor the class members in these regards. Students should therefore maintain high level of discipline and willingness to learn at all times.<br><br> <b>It is compulsory for each class member to have his/her own copy of the <font color="brown">Sunday School guide/manual.</font> This will make it possible for everyone to follow the lessons very closely. You can get a copy of the Sunday School Guide/manual at our various branches. To get a copy kindly <a href="branches.php">click here</a></b></p>


                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div> 
<?php include './includes/footer.php';?>