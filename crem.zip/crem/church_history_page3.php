<?php
 $pageTitle = "Church History | Christ Redemption International";

include("includes/header.php");

?>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">
                        <p align="justify">It is important to note that at that point in time, the interest in the Ministry was not to set up churches in the various towns and cities where the Lord was taking it. It was rather to edify the existing body of Christ, to make it more effective in evangelism. The exigencies of effectively implementing this agenda however made the setting up of churches eventually imperative. By <font color="blue">1998,</font> the weekly and periodic meetings of the Ministry at Ile-Ife devoloved into a church and the branch in the ancient city was launched. The Ejigbo City wide crusade which followed that of Ile-Ife, took the Ministry of Ejigbo and environ. For those who knew about the crusade, that week long programme has so much impact that remains till today.</p><br><br><p><font size="5" color="brown"><b>Consolidating Period</b></font><br>This period is so called because it took the church further and wider into other parts of the country and abroad, requiring approaches that were fundamentally different from those of the early efforts. The period started from about <font color="blue">1996,</font> when branches grew up in many locations particularly in Abuja, Lagos, Port Harcourt, and Ibadan, Ghana and <font color="brown">Cote d'Ivoire</font>. The period is also significant as it marked a time when there was an influx and out movement of pastors that came from outside were obviously looking for paid emnployments. It took no time for many of the to leave: the church was not bread and butter it was primamrily for eternity. This nevertheless gave impetus for the church to look inward for her own commissioned' officers. Within a short period of time, more than ten young men and women were ordained as ministers of God. Since then, ordination and commissioning of young men and women had continued on a yearly basis. Many of these remain able hands up till today.<br><br><p><font size="5" color="brown"><b>Looking into the future</b></font><br>The church has come thus far and looking back, there is a reason to bless the Lord. However, it is not over until it is over. We must keep the faith until the end <font color="green"><b>(Matt 24:13; Heb 13:1-6).</b></font><br><br>The challenge of the future is considerable as the political and economic landscapes of the country and the world as a whole change. A major factor the <b>ICT</b> which is exposing the church to the influence of the larger society more than before. This has been so permeating that many young people now worship on the <b>web!</b> Very closely related to this is the growing number of churches as everyone strives to be a <b>G.O.</b>The immodest living of many ordained servants of God is also creating confusion among people who would like to live simple Christly life. And really, looking through the history of Christianity, those men and women who have made lasting impact were those who were modest. This is a challenge for the growing undue emphasis among Christians on prosperity.<br><br>A greater challenge which must be food for thought for the Pentecostal movement as a whole is the source of converts from evangelistic drives.<br><font color="blue">Are the new converts not just converts from other churches?<br>How many of these are non-Christians?</font><br>A critical look will show that conversions and swelling of the population of many churches today is due to switching of Christians from one denomination to the other. The Lord wants us to target the <b>non-belivers</b> whose numbers are growing tremendously across the globe. In some countries, congregating in the name of Jesus is forbidden and the attacks from non-Christians are becoming far more vicious than before. We must focus on what is necessary to bring many more people to the side of Christ. This is only possible through Holy Spirit-filled living and prayers.<br><br>In all these, we must remain focused. The Bible must for all seasons and circumstances be the standard no matter what the world may be preaching. We must not succumb to the pressure of this age which the Bible calls the perilous time <font color="green"><b>(2Tim 3:1-10).</b></font> As our church goes into the next decade we must move into the core area of envangelism. The call is urgent as the Owner is close by. We will not disappoint Him in Jesus' name.</p>
                        <ul class="pagination pagination-lg">
                            <li><a href="church_history.php">1</a></li>
                            <li><a href="church_history_page2.php">2</a></li>
                            <li class="disabled"><a href="#">3</a></li>  
                            </ul>


                        
                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

<?php include './includes/footer.php';?>