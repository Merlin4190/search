<h1 style="text-align: left;">Welcome Admin</h1>
<ul id='adminmenu'>
	<li><a href='index.php'>Blog</a></li>
	<li><a href='g-desk.php'>G.O's Desk</a></li>
	<li><a href='users.php'>Users</a></li>
	<li><a href="../blog.php" target="_blank">View Blog</a></li>
	<li><a href="../GO_desk.php" target="_blank">View G.O's Desk</a></li>
	<li><a href="../panel.php" target="_blank">Subscription Panel</a></li>
	<li><a href='logout.php'>Logout</a></li>
</ul>
<div class='clear'></div>
<hr / style="width: 100%;">