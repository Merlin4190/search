<?php
$pageTitle = "Admin";
//include config
require_once('../includes/config.php');

//if not logged in redirect to login page
if(!$user->is_logged_in()){ header('Location: login.php'); }

//show message from add / edit page
if(isset($_GET['delpost'])){ 

	$stmt = $db->prepare('DELETE FROM blog_posts WHERE postID = :postID') ;
	$stmt->execute(array(':postID' => $_GET['delpost']));

	header('Location: index.php?action=deleted');
	exit;
} 

?>
<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
<!-- 
Kool Store Template
http://www.templatemo.com/preview/templatemo_428_kool_store
-->
    <meta charset="utf-8">
    <title> <?php echo $pageTitle ?></title>
    <link rel="shortcut icon" href="../images/logo1.png" >
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">

    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/normalize.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    <link rel="stylesheet" href="../css/templatemo-misc.css">
    <link rel="stylesheet" href="../css/templatemo-style.css">
    <link rel="stylesheet" href="../css/templatemo_style.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.5.0/css/font-awesome.css">
    <script src="js/vendor/modernizr-2.6.2.min.js"></script>

</head>
<body>
    <!--[if lt IE 7]>
    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->

    
     <header class="site-header">
        <div class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="top-header-left">
                        <p>CONTACT US|FOLLOW US ON SOCIAL MEDIA</p>
                        </div> <!-- /.top-header-left -->
                    </div> <!-- /.col-md-6 -->
                    <div class="col-md-6 col-sm-6">
                        <div class="social-icons">
                            <ul>
                                <li><a href="../branches_usa.php"><img src="../images/usa.jpeg" alt="USA Flag" width="10px" height="10px" title="United States Branch"></a></li>
                                <li><a href="../branches_headquarter.php"><img src="../images/Nigeria.jpg" alt="Nigeria Flag" width="10px" height="10px" title="Nigeria"></a></li>
                                <li><a href="../branches_ghana.php"><img src="../images/ghana.png" alt="Ghana Flag" width="10px" height="10px" title="Ghana Branch"></a></li>
                                <li><a href="../branches_south-africa.php"><img src="../images/southafrica.jpg" alt="South Africa Flag" width="10px" height="10px" title="South-Africa Branch"></a></li>
                                <li><a href="../branches_coted'ivoire.php"><img src="../images/cotedivoire.jpg" alt="Cote d' ivoire Flag" width="10px" height="10px" title="Cote d'ivoire Branch"></a></li>                                
                                <li><a href="https://www.facebook.com/livingpowerchurch" class="fa fa-facebook"></a></li>
                                <li><a href="#" class="fa fa-instagram"></a></li>
                                <li><a href="https://www.youtube.com/channel/UCs16bHr2TYZiWb7ARyletYQ" class="fa fa-youtube"></a></li>
                                <li><a href="https://www.twitter.com/CREMworldwide" class="fa fa-twitter"></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div> <!-- /.social-icons -->
                    </div> <!-- /.col-md-6 -->
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.top-header -->
        <!-- Navbar Up -->
    <nav class="topnavbar navbar-default topnav">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed toggle-costume" data-toggle="collapse" data-target="#upmenu" aria-expanded="false">
                    <span class="sr-only"> Toggle navigaion</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="col-xs-12">
                <a class="logo" href="../index.php" title="Home"><img src="../images/logo.png" alt="logo" width="328px" height="89px" class="logo"></a>
                </div>
                
            </div>   
        </div>

        <div class="collapse navbar-collapse" id="upmenu">
            <ul class="nav navbar-nav" id="navbarontop">
                <li class="active"><a href="../index.php" title="Home">HOME</a> </li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="About">ABOUT US <span class="caret"></span></a>
                    <ul class="dropdown-menu dropdowncostume">
                        <li><a href="../church_history.php">Church History</a></li>
                        <li><a href="../vision_mission.php">Our Vision and Mission(Objectives)</a></li>
                        <li><a href="../church_structure.php">Church Structure</a></li>
                    </ul>
                </li>

                 <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="Gallery">GALLERY <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdowncostume">
                            <li><a href="../photos.php">P h o t o s</a></li>
                            <li><a href="../videos_audios.php">Videos and Audios</a></li>                            
                        </ul>
                </li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="Branches">BRANCHES <span class="caret"></span></a>
                    <ul class="dropdown-menu dropdowncostume">
                        <li><a href="../branches_headquarter.php">H e a d - q u a r t e r</a></li>
                        <li class="menu-item dropdown dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">I n t e r n a t i o n a l&nbsp;<span class="fa fa-caret-right"></span></a>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                                        <li><a href="../branches_coted'ivoire.php">COTE D' IVOIRE</a></li>
                                        <li><a href="../branches_ghana.php">G H A N A</a></li>                                     
                                        <li><a href="../branches_south-africa.php">SOUTH-AFRICA</a></li>
                                        <li><a href="../branches_usa.php">U S A</a></li>
                            </ul>
                        </li>
        <li class="menu-item dropdown dropdown-submenu"><a href="#">N I G E R I A&nbsp;<span class="fa fa-caret-right"></span></a>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                        
            <li class="menu-item dropdown dropdown-submenu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">O S U N&nbsp;<span class="fa fa-caret-right"></span></a>
                                <ul class="dropdown-menu multi-column columns-2" role="menu" aria-labelledby="dLabel">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <ul class="multi-column-dropdown">
                                        <li><a href="../branches_ada.php">A D A</a></li>
                                        <li><a href="../branches_ede.php">E D E</a></li>
                                        <li><a href="../branches_ejigbo.php">E J I G B O</a></li>
                                        <li><a href="../branches_gbongan.php">G B O N G A N</a></li>
                                        <li><a href="../branches_ikirun.php">I K I R U N</a></li>
                                        <li><a href="../branches_ilase.php">I L A S E</a></li>                                     
                                                </ul>
                                        </div>
                                        <div class="col-sm-6">
                            <ul class="multi-column-dropdown">                                      
                                        <li><a href="../branches_ife.php">I L E - I F E</a></li>                                  
                                        <li><a href="../branches_ilesa.php">I L E S A</a></li>
                                        <li><a href="../branches_ire.php">I R E</a></li>
                                        <li><a href="../branches_osogbo.php">O S O G B O</a></li>
                                        <li><a href="../branches_origo.php">O R I G O</a></li>                                        
                                        </ul>
                        </div>
                    </div>
                                    </ul>
                            </li>
                            <li><a href="../branches_oyo.php">O Y O</a></li>                                     
                            <li><a href="../branches_kwara.php">K W A R A</a></li>
                            <li><a href="../branches_lagos.php">L A G O S</a></li>
                            <li><a href="../branches_rivers.php">R I V E R S</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>

                     <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="About">PROGRAMMES <span class="caret"></span></a>
                    <ul class="dropdown-menu dropdowncostume">
                        <li><a href="../programmes.php">events & Calendar</a></li>
                        <li><a href="../live_blog_day1.php">JPF 2016 Live Blog</a></li>                        
                    </ul>
                </li>

                 <li>
                    <a href="../blog.php" title="Blog">BLOG</a>
 
                </li>

                <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="Resources">RESOURCES <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdowncostume">
                            <li><a href="../sunday_school_manual.php">Sunday School Manual</a></li>
                            <li><a href="../house_fellowship.php">House Fellowship</a></li>
                            <li><a href="#">Bible Study Manual</a></li>
                            <li><a href="#">S T O R E S</a></li>
                        </ul>
                </li>

               

                <li>
                    <a href="../project.php" title="Projects">PROJECTS</a>
 
                </li>

               <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="Ministry">MINISTRY <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdowncostume">
                            <li><a href="../ministry_bible_college.php">International Theological Seminary</a></li>
                            <li><a href="../ministry_mount_zion_school.php">Mount Zion Int'l School</a></li>
                        </ul>
                </li>
                <li class="navbarontop" >
                <div id="templatemo_search">
            <form action="../search.php" method="Get">
              <input type="text" value=" " name="query" id="keyword" title="keyword" onfocus="clearText(this)" onblur="clearText(this)" class="txt_field" />
              <input type="submit" name="Search" value=" " alt="Search" id="searchbutton" title="Search" class="sub_btn"  />
            </form>
        </div>
            </li>
            </ul>
            
    </nav>
</div>
    </header> <!-- /.site-header -->
  <script language="JavaScript" type="text/javascript">
  function delpost(id, title)
  {
	  if (confirm("Are you sure you want to delete '" + title + "'"))
	  {
	  	window.location.href = 'index.php?delpost=' + id;
	  }
  }
  </script>
</head>
<body>

	<div id="wrapper">

	<?php include('menu.php');?>

	<?php 
	//show message from add / edit page
	if(isset($_GET['action'])){ 
		echo '<h3>Post '.$_GET['action'].'.</h3>'; 
	} 
	?>

	<table class="table">
	<thead>
	<tr>
		<th>Title</th>
		<th>Date</th>
		<th>Action</th>
	</tr>
	</thead>
	<?php
		try {

			$stmt = $db->query('SELECT postID, postTitle, postDate FROM blog_posts ORDER BY postID DESC');
			while($row = $stmt->fetch()){
				echo '<tbody>';
				echo '<tr>';
				echo '<td>'.$row['postTitle'].'</td>';
				echo '<td>'.date('jS M Y', strtotime($row['postDate'])).'</td>';
				?>

				<td>
					<a href="edit-post.php?id=<?php echo $row['postID'];?>">Edit</a> | 
					<a href="javascript:delpost('<?php echo $row['postID'];?>','<?php echo $row['postTitle'];?>')">Delete</a>
				</td>
				
				<?php 
				echo '</tr>';
				echo '</tbody>';

			}

		} catch(PDOException $e) {
		    echo $e->getMessage();
		}
	?>
	</table>

	<p><a href='add-post.php'>Add Post</a></p>

</div>
 <footer class="site-footer">
 <div class="main-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <div class="footer-widget">
                            <h3 class="widget-title">Contact Address</h3>
                            <span class="fa fa-map-marker"></span> New Oba Rd, Federal Housing Estate Ile-Idande, Osogbo Osun State.<BR/>
                            <span class="fa fa-mobile-phone"></span> +(234)803-357-4655, +(234)706-674-6001.<BR/>
                            <span class="fa fa-phone"></span> Prayer Helpline: +(234)803-357-4655, +(234)803-351-1747,<BR/> +(234) 803 -719-3141, +(234)807-647-4324.<BR/>
                            <span class="fa fa-envelope"></span> christredemptionmin@yahoo.com, info@christredemptioninternational.org
                            <ul class="follow-us">
                                <li><a href="https://www.facebook.com/livingpowerchurch"><i class="fa fa-facebook"></i>Facebook</a></li>
                                <li><a href="https://www.twitter.com/CREMworldwide"><i class="fa fa-twitter"></i>Twitter</a></li>
                            </ul> <!-- /.follow-us -->
                        </div> <!-- /.footer-widget -->
                    </div> <!-- /.col-md-3 -->
                    
                    <div class="col-md-2">
                        <div class="footer-widget">
                            <h3 class="widget-title">Useful Links</h3>
                            <ul>
                                <li><a href="../GO_desk.php">G.O's Desk</a></li>
                                <li><a href="../church_history.php">Church History</a></li>
                                <li><a href="../church_structure.php">Church Structure</a></li>
                                <li><a href="../vision_mission.php">Our Objectives</a></li>
                                <li><a href="../branches.php">Branches</a></li>
                                <li><a href="../ministry_bible_college.php">Bible College</a></li>
                                <li><a href="../blog.php">Blog</a></li>
                                <li><a href="../photos.php">Gallery</a></li>
                                <li><a href="https://standard5.doveserver.com:2096/">Mail</a></li>
                            </ul>
                        </div> <!-- /.footer-widget -->
                    </div> <!-- /.col-md-2 -->
                    <div class="col-md-4">
                        <div class="footer-widget">
                            <h3 class="widget-title">Our Newsletter</h3>
                            <div class="newsletter">
                                <form action="" method="post">
                                    <p>Sign up to join our mailing list for our latest editorials, prophetic messages and news.</p>
                                    <input type="text" title="Email" name="email" placeholder="Your Email Here">
                                    <input type="submit" class="s-button" value="Submit" name="Submit">
                                    <?php
                                $user="root";
                                $password="";
                                $database="localhost";
                                
                                mysql_connect("localhost","root","") or die("cannot connect to server");
                                mysql_select_db("christr4_crem") or die("cannot connect to database");

                                if(isset($_POST['Submit'])){$email=$_POST['email'];

                                mysql_query("INSERT INTO editorial VALUES ('$email')");

                                mysql_close();}

                                ?>
                                </form>
                                
                            </div> <!-- /.newsletter -->
                        </div> <!-- /.footer-widget -->
                    </div> <!-- /.col-md-4 -->
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.main-footer -->
        <div class="bottom-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <span>Copyright &copy; 2016 <a href="../index.php">Christ Redemption International</a></span>
                        <p><a href="#">Privacy Policy | </a>CREM YOUTH, ICT DEPARTMENT</p>
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.bottom-footer -->
    </footer> <!-- /.site-footer -->

    
    <script src="../js/vendor/jquery-1.10.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="../js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="../js/jquery.easing-1.3.js"></script>
    <script src="../js/bootstrap.js"></script>
    <script src="../js/plugins.js"></script>    
    <script src="../js/main.js"></script>
</body>
</html>