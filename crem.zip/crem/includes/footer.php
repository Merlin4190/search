 <footer class="site-footer">
 <div class="main-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <div class="footer-widget">
                            <h3 class="widget-title">Contact Address</h3>
                            <span class="fa fa-map-marker"></span> New Oba Rd, Federal Housing Estate Ile-Idande, Osogbo Osun State.<BR/>
                            <span class="fa fa-mobile-phone"></span> +(234)803-357-4655, +(234)706-674-6001.<BR/>
                            <span class="fa fa-phone"></span> Prayer Helpline: +(234)803-357-4655, +(234)803-351-1747,<BR/> +(234) 803 -719-3141, +(234)807-647-4324.<BR/>
                            <span class="fa fa-envelope"></span> christredemptionmin@yahoo.com, info@christredemptioninternational.org
                            <ul class="follow-us">
                                <li><a href="https://www.facebook.com/livingpowerchurch"><i class="fa fa-facebook"></i>Facebook</a></li>
                                <li><a href="https://www.twitter.com/CREMworldwide"><i class="fa fa-twitter"></i>Twitter</a></li>
                            </ul> <!-- /.follow-us -->
                        </div> <!-- /.footer-widget -->
                    </div> <!-- /.col-md-3 -->
                    
                    <div class="col-md-2">
                        <div class="footer-widget">
                            <h3 class="widget-title">Useful Links</h3>
                            <ul>
                                <li><a href="GO_desk.php">G.O's Desk</a></li>
                                <li><a href="church_history.php">Church History</a></li>
                                <li><a href="church_structure.php">Church Structure</a></li>
                                <li><a href="vision_mission.php">Our Objectives</a></li>
                                <li><a href="branches.php">Branches</a></li>
                                <li><a href="ministry_bible_college.php">Bible College</a></li>
                                <li><a href="blog.php">Blog</a></li>
                                <li><a href="photos.php">Gallery</a></li>
                                <li><a href="https://standard5.doveserver.com:2096/">Mail</a></li>
                            </ul>
                        </div> <!-- /.footer-widget -->
                    </div> <!-- /.col-md-2 -->
                    <div class="col-md-4">
                        <div class="footer-widget">
                            <h3 class="widget-title">Our Newsletter</h3>
                            <div class="newsletter">
                                <form action="" method="post">
                                    <p>Sign up to join our mailing list for our latest editorials, prophetic messages and news.</p>
                                    <input type="text" title="Email" name="email" placeholder="Your Email Here">
                                    <input type="submit" class="s-button" value="Submit" name="Submit">
                                    <?php
                                $user="root";
                                $password="";
                                $database="localhost";
                                
                                mysql_connect("localhost","root","") or die("cannot connect to server");
                                mysql_select_db("christr4_crem") or die("cannot connect to database");

                                if(isset($_POST['Submit'])){$email=$_POST['email'];

                                mysql_query("INSERT INTO editorial VALUES ('$email')");

                                mysql_close();}

                                ?>
                                </form>
                                
                            </div> <!-- /.newsletter -->
                        </div> <!-- /.footer-widget -->
                    </div> <!-- /.col-md-4 -->
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.main-footer -->
        <div class="bottom-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <span>Copyright &copy; 2016 <a href="#">Christ Redemption International</a></span>
                        <p><a href="#">Privacy Policy | </a>CREM YOUTH, ICT DEPARTMENT</p>
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.bottom-footer -->
    </footer> <!-- /.site-footer -->

    
    <script src="js/vendor/jquery-1.10.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="js/jquery.easing-1.3.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/plugins.js"></script>    
    <script src="js/main.js"></script>
</body>
</html>