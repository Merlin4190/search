<div class="col-md-3 col-sm-6">
                    <div class="product-item">
                        <div class="product-thumb">
                            <img src="images/revelation.jpg" alt="">
                            <img src="images/signs.jpg" alt="">
                            <form action="" method="post">
                            <label for="username" class="control-label">Daily Editorial</label>
                            <input type="text" class="form-control email-form" placeholder="Subscribe(E-mail)" name="mail"><input type="submit" name="Submit" value="Send" id="searchbutton" title="Send" class="btn btn-default btn-submit"  />
                            <?php
                                $user="root";
                                $password="";
                                $database="localhost";
                                
                                mysql_connect("localhost","root","") or die("cannot connect to server");
                                mysql_select_db("christr4_crem") or die("cannot connect to database");

                                if(isset($_POST['Submit'])){$mail=$_POST['mail'];

                                mysql_query("INSERT INTO editorial2 VALUES ('$mail')");

                                mysql_close();}

                                ?>    
                            </form>
                             <form action="" method="post">   
                            <label for="username" class="control-label">Prayer Request</label>
                            <textarea rows="1" cols="27" class="message-form" name="message2"></textarea>
                            <button type="submit" class="btn btn-default btn-submit" title="Submit" name="Submit">Submit</button><BR/>
                            <?php
                                $user="root";
                                $password="";
                                $database="localhost";
                                
                                mysql_connect("localhost","root","") or die("cannot connect to server");
                                mysql_select_db("christr4_crem") or die("cannot connect to database");

                                if(isset($_POST['Submit'])){$message2=$_POST['message2'];

                                mysql_query("INSERT INTO request2 VALUES ('$message2')");

                                mysql_close();}

                                ?> 
                            </form>
                            <label>JPF 2016 live blog <a href="live_blog_day1.php"> More info...</a></label>                            
                        </div> <!-- /.product-thum -->
                    </div> <!-- /.product-item -->
                </div> <!-- /.col-md-3 -->