<?php
 $pageTitle = "Excellent Women | Christ Redemption International";

include("includes/header.php");

?>

<div class="content-section">
        <div class="container">
        <ol class="breadcrumb">
            <li><a href="photos.php">Home</a></li>
            <li class="active">photos_excellent women</li>
        </ol> 
            <div class="row">
                <div class="col-md-9">
                    <div class="product-item-1">
                        <div class="product-content overlay">


                            <h1 align="center"><img src="images/logo1.png"><br>"EXCELLENT WOMEN CONVENTION 2016"</h1>
        <div class="our-partner" style="background-color: transparent;">
            <div class="row">
                <div class="col-md-12">
                    <div class="customNavigation">
                            <a class="btn prev"><i class="fa fa-angle-left"></i></a>
                            <a class="btn next"><i class="fa fa-angle-right"></i></a>
                    </div>

                    <div id="owl-demo" class="owl-carousel">                            
                            <div class="item">
                                <a href="#"><img src="images/crem/women/82.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/57.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/58.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/62.png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/63.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/64.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/65.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/66.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/69.jpg" alt=""></a>
                            </div>
                            <div class="item"> 
                                <a href="#"><img src="images/crem/women/73.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/74.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/75.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/77.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/83.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/84.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/85.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/86.jpg" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (115).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (126).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (134).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (137).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (149).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (172).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (187).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (188).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (192).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (193).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (194).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (201).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (218).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (229).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (233).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (252).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (287).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (305).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (309).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (314).png" alt=""></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/crem/women/Screenshot (327).png" alt=""></a>
                            </div>                           
                    </div> <!-- /#owl-demo -->
                </div> <!-- /.col-md-12 -->
            </div> <!-- /.row -->            
        </div> <!-- /.our-partner -->
                    
           


                        </div> <!-- /.product-content -->
                    </div> <!-- /.product-item-2 -->
                </div>
                <?php include './includes/side.php';?>
            </div>
        </div>
</div>

 <div class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 section-title">
                    <h2>OTHER CLIPS FROM THE WOMEN'S CONVENTION</h2>
                </div> <!-- /.section -->
            </div> <!-- /.row -->
            <div class="row">
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/100.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/101.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/102.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/103.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/104.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/105.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/106.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/107.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/108.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/109.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/110.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
                <div class="col-md-2 col-sm-6">
                    <div class="product-item-vote">
                        <div class="product-thumb">
                            <img src="images/crem/women/111.jpg" alt="">
                        </div> <!-- /.product-thum -->
                        
                    </div> <!-- /.product-item-vote -->
                </div> <!-- /.col-md-3 -->
            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </div> <!-- /.content-section -->


<?php include './includes/footer.php';?>